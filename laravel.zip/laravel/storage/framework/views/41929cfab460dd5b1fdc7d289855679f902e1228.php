<?php /* C:\xampp\htdocs\laravel\resources\views/blogs/create.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('store_blog_path')); ?>" method="POST" enctype="multipart/form-data">
	
	<?php echo csrf_field(); ?>

	<div class="container">
		<br>
		<br>
		<div class="form-group">
			<label for="title">Title</label>
			<input type="text" name="title" class="form-control">
		</div>
		<div class="form-group">
			<label for="content">Content</label>
			<textarea type="text" rows="10" name="content" class="form-control"></textarea>
		</div>
		<div class="form-group">
			<input type="file" name="images" class="form-control">
		</div>
		<div class="form-group">
			<button type="Submit" name="" class="btn btn-outline-primary">
				Add Blog Post
			</button>
		</div>
	</div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>