<?php /* C:\xampp\htdocs\laravel\resources\views/blogs/show.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-6">
		<div class="col-md-12">
			<br> <br>
			<div class="card">
				<div class="card-header">
					<a href="<?php echo e(route('blog_path', ['blog' => $blog->id])); ?>">
						<?php echo e($blog->title); ?>

					</a>
				</div>
				<div class="card-body">
					<img src="<?php echo e(asset('public'.$blog->image)); ?>" style="height: 255px;" class="card-img-top">		
					<?php echo e($blog->content); ?>

					<p>Posted: <?php echo e($blog->created_at->diffForHumans()); ?></p>	
				</div>
			</div>
			<br>
			<a href="<?php echo e(route('edit_blog_path', ['blog' => $blog->id])); ?>" class="btn btn-outline-info"> Update Post</a>	
			<br><br>
			<a href="<?php echo e(route('blogs_path')); ?>" class="btn btn-info">Back</a>
			<br><br> 
			<form action="<?php echo e(route('delete_blog_path', ['blog' => $blog->id])); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<?php echo method_field('DELETE'); ?>
				<button type="submit" class="btn btn-outline-danger"> Delete</button>
			</form>
			<br> <br> <br> <br> <br>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>