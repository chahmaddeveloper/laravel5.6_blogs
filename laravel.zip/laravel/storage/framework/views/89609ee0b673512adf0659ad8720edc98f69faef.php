<?php /* C:\xampp\htdocs\laravel\resources\views/blogs/edit.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('update_blog_path', ['blog' => $blog->id])); ?>" method="POST">
	
	<?php echo csrf_field(); ?>

	<?php echo method_field('PUT'); ?>
	<div class="container">
		<br>
		<br>
		<div class="form-group">
			<label for="title">Title</label>
			<input type="text" name="title" class="form-control" value="<?php echo e($blog->title); ?>">
		</div>
		<div class="form-group">
			<label for="content">Content</label>
			<textarea type="text" rows="10" name="content" class="form-control"><?php echo e($blog->content); ?></textarea>
		</div>
		<div class="form-group">
			<button type="Submit" name="" class="btn btn-outline-primary">
				Edit Blog Post
			</button>
		</div>
	</div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>